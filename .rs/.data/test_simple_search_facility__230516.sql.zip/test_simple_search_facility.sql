-- phpMyAdmin SQL Dump
-- version 4.6.0
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2016 at 09:36 PM
-- Server version: 5.6.30
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_simple_search_facility`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `__pk` int(10) UNSIGNED NOT NULL,
  `_fk_property` int(10) UNSIGNED DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`__pk`, `_fk_property`, `start_date`, `end_date`) VALUES
(1, 1, '2015-05-31', '2015-07-26'),
(2, 1, '2015-12-06', '2015-12-13');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `__pk` int(10) UNSIGNED NOT NULL,
  `department_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`__pk`, `department_name`) VALUES
(1, 'Reservations'),
(2, 'Owners'),
(3, 'Customer Care'),
(4, 'Marketing'),
(5, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `__pk` int(10) UNSIGNED NOT NULL,
  `_fk_property` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `percentage` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`__pk`, `_fk_property`, `start_date`, `end_date`, `percentage`) VALUES
(1, 1, '2015-08-30', '2015-01-02', 10.00),
(2, 2, '2015-01-04', '2015-05-02', 20.00),
(3, 3, '2015-05-31', '2015-08-29', 25.00);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `__pk` int(10) UNSIGNED NOT NULL,
  `_fk_department` int(10) UNSIGNED DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`__pk`, `_fk_department`, `first_name`, `last_name`, `age`) VALUES
(1, 3, 'James', 'Rafferty', 21),
(2, 1, 'Ben', 'Jones', 23),
(3, NULL, 'Ross', 'Steinberg', 56),
(4, 4, 'Christine', 'Robinson', 44),
(5, 5, 'John', 'Smith', 38),
(6, 2, 'Claire', 'Jenkins', 41),
(7, 2, 'Zoe', 'Dean', 21);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `__pk` int(10) UNSIGNED NOT NULL,
  `location_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`__pk`, `location_name`) VALUES
(1, 'Cornwall'),
(2, 'Lake District'),
(3, 'Yorkshire'),
(4, 'Wales'),
(5, 'Scotland');

-- --------------------------------------------------------

--
-- Table structure for table `price_bands`
--

CREATE TABLE `price_bands` (
  `__pk` int(10) UNSIGNED NOT NULL,
  `_fk_property` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `price_bands`
--

INSERT INTO `price_bands` (`__pk`, `_fk_property`, `start_date`, `end_date`, `price`) VALUES
(1, 1, '2015-01-04', '2015-05-02', 250.00),
(2, 1, '2015-05-03', '2015-05-30', 300.00),
(3, 1, '2015-05-31', '2015-09-12', 500.00),
(4, 1, '2015-09-13', '2015-11-28', 300.00),
(5, 1, '2015-11-29', '2016-01-02', 100.00),
(6, 2, '2015-01-04', '2016-01-02', 900.00),
(7, 3, '2015-01-04', '2015-05-02', 333.00),
(8, 4, '2015-05-03', '2015-10-03', 666.00),
(9, 4, '2015-10-04', '2016-01-02', 333.00),
(10, 5, '2015-01-04', '2015-05-02', 250.00),
(11, 5, '2015-05-03', '2015-05-30', 500.00),
(12, 5, '2015-05-31', '2015-09-12', 750.00),
(13, 5, '2015-09-13', '2015-11-28', 500.00),
(14, 5, '2015-11-29', '2016-01-02', 250.00);

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `__pk` int(10) UNSIGNED NOT NULL,
  `_fk_location` int(10) UNSIGNED DEFAULT NULL,
  `property_name` varchar(255) DEFAULT NULL,
  `near_beach` tinyint(1) UNSIGNED DEFAULT NULL,
  `accepts_pets` tinyint(1) UNSIGNED DEFAULT NULL,
  `sleeps` tinyint(3) UNSIGNED DEFAULT NULL,
  `beds` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`__pk`, `_fk_location`, `property_name`, `near_beach`, `accepts_pets`, `sleeps`, `beds`) VALUES
(1, 1, 'Sea View', 1, 1, 4, 2),
(2, 3, 'Cosey', 0, 0, 6, 4),
(3, 5, 'The Retreat', 1, 0, 2, 1),
(4, 5, 'Coach House', 0, 1, 5, 3),
(5, 4, 'Beach Cottage', 1, 1, 8, 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`__pk`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`__pk`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`__pk`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`__pk`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`__pk`);

--
-- Indexes for table `price_bands`
--
ALTER TABLE `price_bands`
  ADD PRIMARY KEY (`__pk`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`__pk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `__pk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `__pk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `__pk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `__pk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `__pk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `price_bands`
--
ALTER TABLE `price_bands`
  MODIFY `__pk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `__pk` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
